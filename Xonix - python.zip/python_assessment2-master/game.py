import tkinter as tk
import copy
import random
from PIL import Image, ImageTk 
import time

start_new_round = False

def setWindowDimensions(): #making the window fullscreen, no matter the size of the screen
	window = tk.Tk()
	window.title("Speedy")

	global width, height, size
	width = window.winfo_screenwidth() 
	height = window.winfo_screenheight() - size * 2
	window.attributes('-fullscreen',True) #making the window full screen, without the cross for closing
	window.geometry("%dx%d+0+0" % (width,height))
	return window

def createFrame():#creates the outer line for the very beginning, and the line where the score will be updated
	canvas.create_line(0, 0, width, 0, fill="#913dd1", width=80)
	canvas.create_line(0, 0, 0, height, fill="#913dd1", width=80)
	canvas.create_line(width, 0, width, height, fill="#913dd1", width=80)
	canvas.create_line(0, height, width, height, fill="#913dd1", width=80)
	canvas.create_line(0, window.winfo_screenheight(), width, window.winfo_screenheight(), fill = "black", width = 80)



def createBad1(size): #creates the bad1, which stays in the purple teritorry
	bad1 = canvas.create_rectangle(width/2, height-(size*2), width/2+size, height-size, fill = "orange")	
	return bad1


def createGood(size): #creates the character
	good = canvas.create_rectangle(width/2, size, width/2 + size, size*2, fill = "white")
	return good


def gameMaping(): #makes my own grid, depending on what size of squares I choose
	global size
	global maping
	maping = []
	for i in range(0, int((width*height)/(size*size))):
		maping.append(0)

	for i in range(0, int(width*2/size)):
		maping[i] = 1

	for i in range(0,2):
		for j in range(0, int(height/size)):
			maping[i+(j*int(width/size))] = 1


	for i in range(int(width/size) - 2, int(width/size)):
		for j in range(0, int(height/size)):
			maping[i+(j*int(width/size))] = 1	


	for i in range(int((width/size)*(height/size - 2)), int((width/size)*(height/size))):
		maping[i] = 1		


def leftKey(event): #moves the good charecter to the left
	global direction
	direction = "Left"


def rightKey(event): #moves the good charecter to the right
	global direction
	direction = "Right"

def upKey(event): #moves the good charecter up
	global direction
	direction = "Up"	

def downKey(event): #moves the good charecter down
	global direction
	direction = "Down"

def moveUpLeft(bad): #moves any bad charecter upleft
	global size
	position = []
	position.append(canvas.coords(bad))
	canvas.coords(bad, position[0][0]-size, position[0][1]-size, position[0][0], position[0][1])
	position.clear()

def moveUpRight(bad):#moves any bad charecter upright
	global size
	position = []
	position.append(canvas.coords(bad))
	canvas.coords(bad, position[0][0]+size, position[0][1]-size, position[0][0]+(size*2), position[0][1])
	position.clear()

def moveDownLeft(bad): #moves any bad charecter downleft
	global size
	position = []
	position.append(canvas.coords(bad))
	canvas.coords(bad, position[0][0]-size, position[0][1]+size, position[0][0], position[0][1]+(size*2))
	position.clear()


def moveDownRight(bad):#moves any bad charecter downright
	global size
	position = []
	position.append(canvas.coords(bad))
	canvas.coords(bad, position[0][0]+size, position[0][1]+size, position[0][0]+(size*2), position[0][1]+(size*2))
	position.clear()


def moveGood(): #moves good as well as changing its position in the maping
	global size
	global direction
	if direction == "Left":
		canvas.move(good, -size, 0)	
	elif direction == "Right":
		canvas.move(good, size, 0)
	elif direction == "Up":
		canvas.move(good, 0, -size)
	elif direction == "Down":
		canvas.move(good, 0, size)
	elif direction == "":
		canvas.move(good, 0, 0)	

	positionsGood = []
	positionsGood.append(canvas.coords(good))


	if (positionsGood[0][0] < 0) & (direction == "Left"):
		canvas.coords(good, 0, positionsGood[0][1], size, positionsGood[0][3])

	elif (positionsGood[0][2] > width) & (direction == "Right"):
		canvas.coords(good, width-size, positionsGood[0][1], width, positionsGood[0][3])

	elif (positionsGood[0][3] > height) & (direction == "Down"):
		canvas.coords(good, positionsGood[0][0], height-size, positionsGood[0][2], height)

	elif (positionsGood[0][1] < 0) & (direction == "Up"):
		canvas.coords(good, positionsGood[0][0], 0, positionsGood[0][2], size)

	positionsGood.clear()
	positionsGood.append(canvas.coords(good))	


def positionUpdate(object, type):#updates the maping position of any object
	global size, maping

	a = []
	a.append(canvas.coords(object))
	pos = int((a[0][1]/size)*(width/size) + a[0][0]/size)
	maping[pos] = type
	a.clear()


def allowed(bad, typeb, directionBad): #checks if the position the bad one is about to go in is apropriate to where one's restrictions are
	global maping, size
	posBad = []
	posBad.append(canvas.coords(bad))
	pos = int((posBad[0][1]/size)*(width/size) + (posBad[0][0]/size))
	myType = maping[pos]

	if directionBad == "UpRight":
		if (((pos + 1) - int(width/size))%int(width/size) != 0):
		 	if ((pos + 1) - int(width/size) >= 0):
		 		if (maping[(pos + 1) - int(width/size)] == typeb):
		 			posBad.clear()
		 			return 0
		 		else:
		 			if maping[pos + 1 + int(width/size)] == typeb:
		 				posBad.clear()
		 				return 1
		 			elif maping[(pos - 1) - int(width/size)] == typeb:
		 				posBad.clear()
		 				return 2
		 			elif maping[(pos + 1) - int(width/size)] ==  myType:
		 				posBad.clear()
		 				return 3
		 			else:
		 				posBad.clear()
		 				return 3		
		 	else:
		 		posBad.clear()
		 		return 1						
		else:
		 	posBad.clear()
		 	return 2	



	elif directionBad == "UpLeft":
		if (((pos-1) - int(width/size))%int(width/size) != int(width/size - 1)):
			if ((pos-1) - int(width/size) >= 0):
				if (maping[(pos-1) - int(width/size)] == typeb):
					posBad.clear()
					return 0
				else:
					if (maping[pos - 1 + int(width/size)] == typeb):
						posBad.clear()
						return 1
					elif (maping[pos + 1 - int(width/size)] == typeb):
						posBad.clear()
						return 2
					elif maping[(pos-1) - int(width/size)] == myType:
						posBad.clear()
						return 3			
					else:
						posBad.clear()
						return 3	

			else:	
				posBad.clear()
				return 1

		else:
			posBad.clear()
			return 2	


	elif directionBad == "DownRight":
		if ((pos+1) + int(width/size)) <= len(maping):
			if(((pos+1) + int(width/size))%int(width/size) != 0):
				if (maping[((pos+1) + int(width/size))] == typeb):
					posBad.clear()
					return 0
				else:
					if (maping[(pos + 1 - int(width/size))] == typeb):
						posBad.clear()
						return 1
					elif (maping[(pos - 1 + int(width/size))] == typeb):
						posBad.clear()
						return 2
					elif maping[((pos+1) + int(width/size))] == myType:
						posBad.clear()
						return 3	
					else:
						posBad.clear()
						return 3		

			else:
				posBad.clear()
				return 2				
		else:
			posBad.clear()
			return 1


	elif directionBad == "DownLeft":
		if ((pos-1) + int(width/size)) <= len(maping):
			if(((pos-1) + int(width/size))%(int(width/size))) != (int(width/size) - 1):
				if (maping[((pos-1) + int(width/size))] == typeb):
					posBad.clear()
					return 0
				else:
					if (maping[pos + 1 + int(width/size)] == typeb):
						posBad.clear()
						return 2
					elif (maping[pos - 1 - int(width/size)] == typeb):
						posBad.clear()
						return 1
					elif maping[((pos-1) + int(width/size))] == myType:
						posBad.clear()
						return 3	
					else:
						posBad.clear()
						return 3		


			else:
				posBad.clear()
				return 2

		else:
			posBad.clear()
			return 1	


def moveBad1(): #moving bad1 and updating it's position

	
	global currentDirection, size
	global positionBad1
	positionBad1 = []
	positionBad1.append(canvas.coords(bad1))

	global positionBad11
	positionBad11 = []
	positionBad11.append(canvas.coords(bad1))

		
	if currentDirection == "DownLeft":
		a = allowed(bad1, 1, "DownLeft")
		if  a == 0:
			positionUpdate(bad1, 1)
			moveDownLeft(bad1)
			positionUpdate(bad1, 4)
		elif a == 1:
			positionUpdate(bad1, 1)
			moveUpLeft(bad1)
			currentDirection = "UpLeft"
			positionUpdate(bad1, 4)
		elif a == 2:
			positionUpdate(bad1, 1)
			moveDownRight(bad1)
			currentDirection = "DownRight"
			positionUpdate(bad1, 4)
		elif a == 3:
			positionUpdate(bad1, 1)
			moveUpRight(bad1)
			currentDirection = "UpRight"
			positionUpdate(bad1, 4)			

	elif currentDirection == "DownRight":
		a = allowed(bad1, 1, "DownRight")
		if  a == 0:
			positionUpdate(bad1, 1)
			moveDownRight(bad1)
			positionUpdate(bad1, 4)
			
		elif a == 1:
			positionUpdate(bad1, 1)
			moveUpRight(bad1)
			currentDirection = "UpRight"
			positionUpdate(bad1, 4)
			
		elif a == 2:
			positionUpdate(bad1, 1)
			moveDownLeft(bad1)
			currentDirection = "DownLeft"
			positionUpdate(bad1, 4)
			
		elif a == 3:
			positionUpdate(bad1, 1)
			moveUpLeft(bad1)
			currentDirection = "UpLeft"
			positionUpdate(bad1, 4)
					

	elif currentDirection == "UpLeft":
		a = allowed(bad1, 1, "UpLeft")
		if a == 0:
			positionUpdate(bad1, 1)
			moveUpLeft(bad1)
			positionUpdate(bad1, 4)
		elif a == 1:
			positionUpdate(bad1, 1)
			moveDownLeft(bad1)
			currentDirection = "DownLeft"
			positionUpdate(bad1, 4)
		elif a == 2:
			positionUpdate(bad1, 1)
			moveUpRight(bad1)
			currentDirection = "UpRight"
			positionUpdate(bad1, 4)
		elif a == 3:
			positionUpdate(bad1, 1)
			moveDownRight(bad1)
			currentDirection = "DownRight"
			positionUpdate(bad1, 4)


	elif currentDirection == "UpRight":	
		a = allowed(bad1, 1, "UpRight")		
		if  a == 0:
			positionUpdate(bad1, 1)
			moveUpRight(bad1)
			currentDirection = "UpRight"
			positionUpdate(bad1, 4)				
		elif a == 1:
			positionUpdate(bad1, 1)
			moveDownRight(bad1)
			currentDirection = "DownRight"
			positionUpdate(bad1, 4)
		elif a == 2:
			positionUpdate(bad1, 1)
			moveUpLeft(bad1)
			currentDirection = "UpLeft"
			positionUpdate(bad1, 4)
		elif a == 3:
			positionUpdate(bad1, 1)
			moveDownLeft(bad1)
			currentDirection = "DownLeft"
			positionUpdate(bad1, 4)

	positionBad1.clear()
	positionBad1.append(canvas.coords(bad1))


def createBad2(): #used to create all the bad ones
	global size, maping
	c = False
	while c == False:
		b = random.randint(0, len(maping) - 1)
		if maping[b] == 0:
			bad21 = canvas.create_oval(int(b % (width/size))*size, (int(b/(width/size)))*size, int(b % (width/size))*size + size, (int(b/(width/size)))*size + size, fill = "#7dd13d")
			maping[b] = 5
			c = True		
	return bad21


def moveBad2(i): #used to move all the bad ones


	
	global currentDirection2, size
	global bad2
	global positionBad2
	positionBad2 = []
	positionBad2.append(canvas.coords(bad2[i]))

	if currentDirection2[i] == "DownLeft":


		a = allowed(bad2[i], 0, "DownLeft")
		if  a == 0:
			positionUpdate(bad2[i], 0)
			moveDownLeft(bad2[i])
			positionUpdate(bad2[i], 5)
		elif a == 1:
			positionUpdate(bad2[i], 0)
			moveUpLeft(bad2[i])
			currentDirection2[i] = "UpLeft"
			positionUpdate(bad2[i], 5)
		elif a == 2:
			positionUpdate(bad2[i], 0)
			moveDownRight(bad2[i])
			currentDirection2[i] = "DownRight"
			positionUpdate(bad2[i], 5)
		elif a == 3:
			positionUpdate(bad2[i], 0)
			moveUpRight(bad2[i])
			currentDirection2[i] = "UpRight"
			positionUpdate(bad2[i], 5)			

	elif currentDirection2[i] == "DownRight":
		a = allowed(bad2[i], 0, "DownRight")
		if  a == 0:
			positionUpdate(bad2[i], 0)
			moveDownRight(bad2[i])
			positionUpdate(bad2[i], 5)
			
		elif a == 1:
			positionUpdate(bad2[i], 0)
			moveUpRight(bad2[i])
			currentDirection2[i] = "UpRight"
			positionUpdate(bad2[i], 5)
			
		elif a == 2:
			positionUpdate(bad2[i], 0)
			moveDownLeft(bad2[i])
			currentDirection2[i] = "DownLeft"
			positionUpdate(bad2[i], 5)
			
		elif a == 3:
			positionUpdate(bad2[i], 0)
			moveUpLeft(bad2[i])
			currentDirection2[i] = "UpLeft"
			positionUpdate(bad2[i], 5)
					

	elif currentDirection2[i] == "UpLeft":
		a = allowed(bad2[i], 0, "UpLeft")
		if a == 0:
			positionUpdate(bad2[i], 0)
			moveUpLeft(bad2[i])
			positionUpdate(bad2[i], 5)
		elif a == 1:
			positionUpdate(bad2[i], 0)
			moveDownLeft(bad2[i])
			currentDirection2[i] = "DownLeft"
			positionUpdate(bad2[i], 5)
		elif a == 2:
			positionUpdate(bad2[i], 0)
			moveUpRight(bad2[i])
			currentDirection2[i] = "UpRight"
			positionUpdate(bad2[i], 5)
		elif a == 3:
			positionUpdate(bad2[i], 0)
			moveDownRight(bad2[i])
			currentDirection2[i] = "DownRight"
			positionUpdate(bad2[i], 5)


	elif currentDirection2[i] == "UpRight":	
		a = allowed(bad2[i], 0, "UpRight")		
		if  a == 0:
			positionUpdate(bad2[i], 0)
			moveUpRight(bad2[i])
			currentDirection2[i] = "UpRight"
			positionUpdate(bad2[i], 5)				
		elif a == 1:
			positionUpdate(bad2[i], 0)
			moveDownRight(bad2[i])
			currentDirection2[i] = "DownRight"
			positionUpdate(bad2[i], 5)
		elif a == 2:
			positionUpdate(bad2[i], 0)
			moveUpLeft(bad2[i])
			currentDirection2[i] = "UpLeft"
			positionUpdate(bad2[i], 5)
		elif a == 3:
			positionUpdate(bad2[i], 0)
			moveDownLeft(bad2[i])
			currentDirection2[i] = "DownLeft"
			positionUpdate(bad2[i], 5)

	positionBad2.clear()
	positionBad2.append(canvas.coords(bad2[i]))


def DFS(where): #checks when a territory is surrounded if there are bad ones inside it. If there are none - the teritorry can now be part of the good one's territory
	global maping2, size
	stack = [where]
	while(len(stack) > 0):
		curr = stack[len(stack) - 1]
		stack.pop()
		if maping2[curr] == 0 or maping2[curr] == 5:
			maping2[curr] = 1
			if maping2[curr-1] == 0 or maping2[curr-1] == 5:
				stack.append(curr - 1)
			if maping2[curr+1] == 0 or maping2[curr+1] == 5:
				stack.append(curr + 1)
			if maping2[curr - int(width/size)] == 0 or maping2[curr - int(width/size)] == 5:
				stack.append(curr - int(width/size))
			if maping2[curr + int(width/size)] == 0 or maping2[curr + int(width/size)] == 5:
				stack.append(curr + int(width/size))


def filling(): #fills in the territory, after making sure it is really empty
	global maping2, size, nomerator, score, denominator, oldscore, maping
	global stack 
	maping2 = []
	for i in range(0, len(maping)):
		maping2.append(maping[i])

	
	for i in range (0, len(maping2)):
		if maping2[i] == 5:
			DFS(i)

	for i in range(0, len(maping2)):
		if maping2[i] == 0:
			tmp = canvas.create_rectangle(int(i%(width/size))*size, int(i/(width/size))*size, int(i%(width/size))*size + size, int(i/(width/size))*size + size, fill = "#913dd1", outline = "")
			canvas.tag_lower(tmp)
			maping[i] = 1
			nomerator += 1

	score = oldscore + int((nomerator/denominator)*10000)
	maping2.clear()	

		
def deathOfLine():#checks if the any bad2 one has crashed into the blue line 
	global bad2, size
	global currentDirection2
	for i in range(0, len(bad2)):

		a = allowed(bad2[i], 2, currentDirection2[i])
		if a == 0:
			return True

	return False		


def deathOfCollision(good): #checks if the good one has collided with any of the bad ones
	global size, maping
	a = []
	a.append(canvas.coords(good))
	pos = int((a[0][1]/size)*(width/size) + a[0][0]/size)
	if (maping[pos] == 2):
		return 2
	elif (maping[pos] == 4):
		return 4
	elif (maping[pos] == 5):
		return 5

	elif (maping[pos] == 0):
		return 0
	elif(maping[pos] == 1):		
		return 1	
def unPause(event):
	global paused
	window.unbind("<p>")
	window.bind("<p>", pause)
	delay()



def update():#main functionality of the game. When getting updated all the objects move
	global txt, nomerator, denominator, lives, rund, score, scoreText, size, oldscore, start_new_round
	
	global direction, paused
	if paused == True:
		window.after(48 - 3*rund, update)
		window.bind("<b>", unBossKey)
		window.bind("<p>", unPause)
		return

	if start_new_round:
		start_new_round = False
		init(rund, score, oldscore, nomerator)
		return
	global good
	global maping
	global currentBlue
	# currentBlue = []
	global blue
	dcl = deathOfCollision(good)

	# for i in range(0,int(height/size)):
	# 	for j in range(0,int(width/size)):
	# 		print(maping[(i*(int(width/size)))+j], end = "")
	# 	print('\n')	
	# print('\n')	
		
	if (dcl == 0) or (dcl == 1):
		moveBad1()



		if dcl == 0:
			moveGood()
			positionGood = []
			positionGood.append(canvas.coords(good))
			posGood = int(((positionGood[0][1]/size)*(width/size)) + (positionGood[0][0]/size))
			if (direction == "Right") & (maping[posGood - 1] != 1) & ((maping[posGood + 1] == 0) or (maping[posGood + 1] == 1)):
				maping[posGood - 1] = 2
				currentBlue.append(posGood - 1)
				blue.append(canvas.create_rectangle(positionGood[0][0] - size, positionGood[0][1], positionGood[0][2] - size, positionGood[0][3], fill = "blue"))
				

			elif (direction == "Left") & (maping[posGood + 1] != 1) & ((maping[posGood - 1] == 0) or maping[posGood - 1] == 1):
				maping[posGood + 1] = 2
				currentBlue.append(posGood + 1)
				blue.append(canvas.create_rectangle(positionGood[0][0] + size, positionGood[0][1], positionGood[0][2] + size, positionGood[0][3], fill = "blue"))

			elif (direction == "Up") & (maping[posGood + int(width/size)] != 1) & ((maping[posGood - int(width/size)] == 0) or (maping[posGood + int(width/size)] == 0)):
				maping[posGood + int(width/size)] = 2
				currentBlue.append(posGood + int(width/size))
				blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] + size, positionGood[0][2], positionGood[0][3] + size, fill = "blue"))

			elif (direction == "Down") & (maping[posGood - int(width/size)] != 1) & ((maping[posGood + int(width/size)] == 0) or (maping[posGood + int(width/size)] == 1)):	
				maping[posGood - int(width/size)] = 2
				currentBlue.append(posGood - int(width/size))
				blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] - size, positionGood[0][2], positionGood[0][3] - size, fill = "blue"))

			positionGood.clear()	
			


			if deathOfLine() == False:
				for i in range(0, 2+rund):
					moveBad2(i)

				if int((nomerator/denominator)*100) >= 70:
					rund += 1
					oldscore = oldscore + score
					score = 0
					nomerator = 0
					canvas.delete("all")

					init(rund, score, oldscore, nomerator)
					return

				else:	
					window.after(48 - 3*rund, update)
			else:
				
				oldscore = oldscore + score
				score = 0
				lives -= 1
				# nomerator = 0
				if lives == 0:
					return
				canvas.delete("all")
				for i in range(0, len(maping)):
					if maping[i] == 2 or maping[i] == 5:
						maping[i] = 0
					if maping[i] == 4:
						maping[i] = 1	

				init(rund, score, oldscore, nomerator)
				return		


		elif dcl == 1:
			if (len(currentBlue) == 0):
				moveGood()	

			positionGood = []
			positionGood.append(canvas.coords(good))
			posGood = int(((positionGood[0][1]/size)*(width/size)) + (positionGood[0][0]/size))


			if (len(currentBlue) > 0):
				if direction == "Up":
					maping[posGood + int(width/size)] = 2
					currentBlue.append(posGood + int(width/size))
					blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] + size, positionGood[0][2], positionGood[0][3] + size, fill = "blue"))
					direction = ""


				elif direction == "Down":
					maping[posGood - int(width/size)] = 2
					currentBlue.append(posGood - int(width/size))
					blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] - size, positionGood[0][2], positionGood[0][3] - size, fill = "blue"))
					direction = ""

				elif direction == "Right":
					maping[posGood - 1] = 2
					currentBlue.append(posGood - 1)
					blue.append(canvas.create_rectangle(positionGood[0][0] - size, positionGood[0][1], positionGood[0][2] - size, positionGood[0][3], fill = "blue"))
					direction = ""

				elif direction == "Left":	
					maping[posGood + 1] = 2
					currentBlue.append(posGood + 1)
					blue.append(canvas.create_rectangle(positionGood[0][0] + size, positionGood[0][1], positionGood[0][2] + size, positionGood[0][3], fill = "blue"))
					direction = ""

				
				for i in range(0, len(currentBlue)):
					maping[currentBlue[i]] = 1

					canvas.delete(blue[i])
					tmp = canvas.create_rectangle(int(currentBlue[i]%(width/size))*size, int(currentBlue[i]/(width/size))*size, int(currentBlue[i]%(width/size))*size + size, int(currentBlue[i]/(width/size))*size + size, fill = "#913dd1", outline = "")
					canvas.tag_lower(tmp)
					nomerator += 1

					
				
				score = oldscore + ((nomerator/denominator)*10000)
				filling()
				sc = score
				txt = "Full:" + str(int((nomerator/denominator)*100)) + "%		Lives:" + str(lives) + "		Round:" + str(rund) + "		Score:" + str(sc)
	
				canvas.itemconfigure(scoreText, text=txt)	

				blue.clear()

				currentBlue.clear()

	
	
				
			positionGood.clear()

			if deathOfLine() == False:
				for i in range(0, 2+rund):
					moveBad2(i)


				if int((nomerator/denominator)*100) >= 70:
					rund += 1
					oldscore = score
					score = 0
					nomerator = 0
					canvas.delete("all")
					gameMaping()

					init(rund, score, oldscore, nomerator)
					return
				else:	
					window.after(48 - 3*rund, update)




	elif dcl == 4:
		global positionBad1
		pos = int((positionBad11[0][1]/size)*(width/size) + positionBad11[0][0]/size)
		maping[pos] = 4
		killingBad1 = canvas.create_rectangle(positionBad11[0][0], positionBad11[0][1], positionBad11[0][2], positionBad11[0][3], fill = "orange")
		oldscore = oldscore + score
		score = 0
		lives -= 1
		# nomerator = 0
		if lives == 0:

			return
		canvas.delete("all")
		for i in range(0, len(maping)):
			if maping[i] == 2 or maping[i] == 5:
				maping[i] = 0
			if maping[i] == 4:
				maping[i] = 1	
		init(rund, score, oldscore, nomerator)
		return


	elif dcl == 2:
		positionGood = []
		positionGood.append(canvas.coords(good))

		if direction == "Up":

			canvas.create_rectangle(positionGood[0][0], positionGood[0][1] + size, positionGood[0][2], positionGood[0][3] + size, fill = "white")
			positionGood[0][1] = positionGood[0][1] + size
			positionGood[0][3] = positionGood[0][3] + size
			

		elif direction == "Down":
	
			canvas.create_rectangle(positionGood[0][0], positionGood[0][1] - size, positionGood[0][2], positionGood[0][3] - size, fill = "white")

			positionGood[0][1] = positionGood[0][1] - size
			positionGood[0][3] = positionGood[0][3] - size

		elif direction == "Right":

			canvas.create_rectangle(positionGood[0][0] - size, positionGood[0][1], positionGood[0][2] - size, positionGood[0][3], fill = "white")
			positionGood[0][0] = positionGood[0][0] - size
			positionGood[0][2] = positionGood[0][2] - size

		elif direction == "Left":	

			canvas.create_rectangle(positionGood[0][0] + size, positionGood[0][1], positionGood[0][2] + size, positionGood[0][3], fill = "white")

			positionGood[0][0] = positionGood[0][0] + size
			positionGood[0][2] = positionGood[0][2] + size

		if (len(currentBlue) > 0):
				if direction == "Up":
					blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] + size, positionGood[0][2], positionGood[0][3] + size, fill = "blue"))

				elif direction == "Down":
					blue.append(canvas.create_rectangle(positionGood[0][0], positionGood[0][1] - size, positionGood[0][2], positionGood[0][3] - size, fill = "blue"))

				elif direction == "Right":
					blue.append(canvas.create_rectangle(positionGood[0][0] - size, positionGood[0][1], positionGood[0][2] - size, positionGood[0][3], fill = "blue"))

				elif direction == "Left":	
					blue.append(canvas.create_rectangle(positionGood[0][0] + size, positionGood[0][1], positionGood[0][2] + size, positionGood[0][3], fill = "blue"))




		positionGood.clear()
		oldscore = oldscore + score
		score = 0
		lives -= 1
		canvas.itemconfigure(scoreText, text=txt)	
		# nomerator = 0
		if lives == 0:

			return
		canvas.delete("all")
		for i in range(0, len(maping)):
			if maping[i] == 2 or maping[i] == 5:
				maping[i] = 0
			if maping[i] == 4:
				maping[i] = 1	
		init(rund, score, oldscore, nomerator)
		return
		
	elif dcl == 5:
		global bad2
		global currentDirection2

		for i in range(0, 2 + rund):
			g = []
			g.append(canvas.coords(good))
			k = []
			k.append(canvas.coords(bad2[i]))
			if (k[0][0] == g[0][0]) & (k[0][1] == g[0][1]):
				if currentDirection2[i] == "UpRight":
					currentDirection2[i] = "DownLeft"
					moveBad2(i)


				elif currentDirection2[i] == "UpLeft":
					currentDirection2[i] = "DownRight"
					moveBad2(i)

				elif currentDirection2[i] == "DownRight":
					currentDirection2[i] = "UpLeft"
					moveBad2(i)

				elif currentDirection2[i] == "DownLeft":
					currentDirection2[i] = "UpRight"
					moveBad2(i)					
		oldscore = oldscore + score
		score = 0
		lives -= 1
		if lives == 0:

			return	
		canvas.delete("all")

		for i in range(0, len(maping)):
			if maping[i] == 2 or maping[i] == 5:
				maping[i] = 0
			if maping[i] == 4:
				maping[i] = 1	
		init(rund, score, oldscore, nomerator)
		return
					

def loadmaping(): #loads a maping if it is not a new game, but for example the good one has died
	global maping
	for i in range(0, len(maping)):
		if maping[i] == 1:
			canvas.create_rectangle(int(i%(width/size))*size, int(i/(width/size))*size, int(i%(width/size))*size + size, int(i/(width/size))*size + size, fill = "#913dd1", outline = "")


def delay(left = 3):
	global delaying, paused

	if left == 0:
		delaying.destroy()
		paused = False
		return

	if left == 3:
		delaying = tk.Label(window, height = 1, width = 1, fg = "red", background = "black",  font = "Times 100 italic bold", text = str(left))
	else:
		delaying.config(text=str(left))

	delaying.place(x = width/2, y = height/2)

	window.after(1000, lambda: delay(left-1))




def init(rounding, scoring, oldscores, nomerators):#other important funtionallity - for things that need to be updated occasionally - like only if you have died you need to load the maping
	createFrame()
	loadmaping()
	global oldscore
	oldscore = oldscores
	canvas.pack()
	global bad1, size
	global good
	bad1 = createBad1(size)
	global currentDirection
	global direction
	direction = ""
	global currentBlue
	currentBlue = []
	currentDirection = ""
	global txt, nomerator, denominator, lives, rund, scoreText
	nomerator = nomerators
	global blue
	blue = []
	global rund
	rund = rounding
	
	global score
	score = scoring
	
	directionBad = random.randint(1,2)
	if directionBad == 1:
		positionUpdate(bad1, 1)
		moveDownLeft(bad1)
		currentDirection = "DownLeft"
		positionUpdate(bad1, 4)

	elif directionBad == 2:
		positionUpdate(bad1, 1)
		moveDownRight(bad1)
		currentDirection = "DownRight"
		positionUpdate(bad1, 4)

	good = createGood(size)

	global bad2
	bad2 = []
	global currentDirection2
	currentDirection2 = []

	for i in range(2+rund):
		currentDirection2.append("")
		bad2.append(createBad2())
		originalDir = random.randint(1, 4)
		
		if originalDir == 1:
			positionUpdate(bad2[i], 0)
			moveDownLeft(bad2[i])
			currentDirection2[i] = "DownLeft"
			positionUpdate(bad2[i], 5)

		elif originalDir == 2:
			positionUpdate(bad2[i], 0)
			moveDownRight(bad2[i])
			currentDirection2[i] = "DownRight"
			positionUpdate(bad2[i], 5)

		elif originalDir == 3:
			positionUpdate(bad2[i], 0)
			moveUpLeft(bad2[i])
			currentDirection2[i] = "UpLeft"
			positionUpdate(bad2[i], 5)

		elif originalDir == 4:
			positionUpdate(bad2[i], 0)
			moveUpRight(bad2[i])
			currentDirection2[i] = "UpRight"
			positionUpdate(bad2[i], 5)				
	global sc		
	sc = oldscore + score		
	txt = "Full:" + str(int((nomerator/denominator)*100)) + "%		Lives:" + str(lives) + "		Round:" + str(rund) + "		Score:" + str(sc)
	scoreText = canvas.create_text(width/7*5, height + size, fill="white", font="Times 20 italic bold", text=txt)
		

	update()	

def newGame():#if you start a new game it sets starting values for some of the variables
	global paused
	paused = False
	oldscore = 0

	nomerator = 0

	global lives
	lives = 3
	scoring = 0
	rund = 1


	gameMaping()
	

	init(rund, scoring, oldscore, nomerator)

global size
size = 20
window = setWindowDimensions()

canvas = tk.Canvas(window, bg="black", width=width, height=height + size*2)



global denominator
denominator = int((height / size - 4) * (width / size - 4))


def loadGame(fileName):
	pass


def pause(event):
	pass

def hideMainMenu():
	global newGameButton, loadGameButton, leaderboardButton, cheatCodesButton, controlSettingsButton, howToPlayButton, logo

	newGameButton.pack_forget()
	loadGameButton.pack_forget()
	leaderboardButton.pack_forget()
	howToPlayButton.pack_forget()
	cheatCodesButton.pack_forget()
	controlSettingsButton.pack_forget()
	logo.pack_forget()

def keys():#binding the movement of the good one to the keyboard
	window.bind("<Left>", leftKey)
	window.bind("<Right>", rightKey)
	window.bind("<Up>", upKey)
	window.bind("<Down>", downKey)

def newGameButton():
	keys()
	hideMainMenu()

	newGame()

def loadGameButton():
	pass

def leaderboardButton():
	pass	

def cheatCodesButton():
	pass

def controlSettingsButton():
	pass

def mainMenuButtons():
	global newGameButton, loadGameButton, leaderboardButton, cheatCodesButton, controlSettingsButton, howToPlayButton, width, height

	newGameButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold",   text = "New Game", command = newGameButton)


	loadGameButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold", text = "Load Game", command = loadGameButton)


	leaderboardButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold", text = "Leaderboard", command = leaderboardButton)


	howToPlayButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold", text = "How to play", command = howToPlayButton)

	cheatCodesButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold", text = "Cheat codes", command = cheatCodesButton)


	controlSettingsButton = tk.Button(window, width = 30, height = 4, bg = "#913dd1", font="Times 17 italic bold", text = "Control settings", command = controlSettingsButton)



def mainMenuPicture():
	
	global logo
	img = Image.open("speedy.gif")

	img = ImageTk.PhotoImage(img.resize((504, 896), Image.ANTIALIAS))
	logo = tk.Label(window, image = img)
	logo.image = img
	

def mainMenuTitle():
	pass		
def howToPlayButton():
	pass

def createMainMenu():#creates the main menu, but not showing
	mainMenuButtons()
	mainMenuPicture()

	
def showMainMenu():	#shows you the main menu
	global newGameButton, loadGameButton, leaderboardButton, cheatCodesButton, controlSettingsButton, howToPlayButton, logo


	logo.pack(padx = (0, (width/6)), pady = (80, 0), side = "right", anchor = tk.NW)
	newGameButton.pack(padx = (int(width/8),0), pady = (int(height/7), 10), anchor = "w")

	loadGameButton.pack(padx = (int(width/8),0), pady = (10, 10), anchor = "w")

	leaderboardButton.pack(padx = (int(width/8),0), pady = (10, 10), anchor = "w")

	howToPlayButton.pack(padx = (int(width/8),0), pady = (10, 10), anchor = "w")

	cheatCodesButton.pack(padx = (int(width/8),0), pady = (10, 10), anchor = "w")

	controlSettingsButton.pack(padx = (int(width/8),0), pady = (10, 10), anchor = "w")



def pause(event):
	global paused
	paused = True
	window.unbind("<p>")

def bossKey(event):
	global paused
	paused = True
	window.unbind("<b>")
	window.bind("<b>", unBossKey)
	global boss, bossing
	bossimg = Image.open("bosskey.png")

	bossimg = ImageTk.PhotoImage(bossimg)
	boss = tk.Label(window, image = bossimg)
	boss.image = bossimg
	boss.place(x = 0,y = 0, relwidth = 1, relheight = 1)

def unBossKey(event):
	global paused, boss
	window.unbind("<b>")
	window.bind("<b>", bossKey)	
	boss.destroy()
	delay()


	#show image	

def moreLives(event):
	global lives
	lives += 1



def nextRound(event):
	global start_new_round, rund, score, oldscore, nomerator
	rund +=1 
	oldscore = score
	score = 0
	nomerator = 0
	canvas.delete("all")
	gameMaping()
	start_new_round = True
	# init(rund, score, oldscore, nomerator)
	return
	
window.bind("<l>", moreLives)
window.bind("<r>", nextRound)

window.bind("<Escape>", lambda exit: window.destroy()) 
window.bind("<b>", bossKey)
window.bind("<p>", pause)
window.focus_set()
createMainMenu()
showMainMenu()
# newGame()
window.mainloop() #creates the window and starts the game